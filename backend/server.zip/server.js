const express = require('express');
const app = express();
const cors = require('cors');
const bodyParser = require('body-parser');
const Pokemon = require("./pokemon/pokController");
const connection = require('./bd/bd');
// Pegar a porta automaticamente
const PORT = process.env.PORT || 3333;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/pokemons', Pokemon);

// Realiza a conexao com o bd
connection.authenticate().then(() => {
    console.log('Conexão com o banco de dados realizada com sucesso!');
}).catch((err) => {
    console.log('Erro ao se conectar com o banco de dados: ' + err);
});

app.get('/', (req, res) => {
    res.send('Hello World!');
}
);


app.listen(PORT, () => {
    console.log('Server is running on port 4000');
}
);